﻿const base = {
        url : "http://localhost:8080/ssmk7t62/"
    }
export default base